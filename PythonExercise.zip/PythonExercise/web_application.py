class Student:
    def __init__(self, name, rollno, age, gender):
        self.name = name
        self.rollno = rollno
        self.age = age
        self.gender = gender

    def insert(self, Name, Rollno, Age, Gender ):
        
        ob = Student(Name, Rollno, Age, Gender )
        ls.append(ob)
   
    def display(self, ob):
            print("Name   : ", ob.name)
            print("RollNo : ", ob.rollno)  #Display
            print("age : ", ob.age)
            print("gender : ", ob.gender)
            print("\n")    
         
    def search(self, rn):
        for i in range(ls.__len__()): #Search
            if(ls[i].rollno == rn):
                return i   

    def delete(self, rn):
        i = obj.search(rn)  #Delete
        del ls[i]

    def update(self, rn, No): #Update
        i = obj.search(rn)
        roll = No
        ls[i].rollno = roll;
         
ls =[]

obj = Student('', 0, 0, 0)
  
print("Web Application, ")
print("1.Insert Student Details")
print("2.Display Student Details")
print("3.Search Student Details")
print("4.Delete Student Details") 
print("5.Update Student Details")
  

obj.insert("A", 1, 65, "female")
obj.insert("B", 2, 87, "male")
obj.insert("C", 3, 54, "female")
         
print("\n")
print("\nStudents\n")
for i in range(ls.__len__()):    
    obj.display(ls[i])
             
print("\n Student Present, ")
s = obj.search(2)
obj.display(ls[s])
         
obj.delete(2)
print(ls.__len__())
print("List after deletion")
for i in range(ls.__len__()):    
    obj.display(ls[i])
             
obj.update(3, 2)
print(ls.__len__())
print("List after updation")
for i in range(ls.__len__()):    
    obj.display(ls[i])